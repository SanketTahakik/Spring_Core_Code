package com.java;

public class checkPrimeNumber 
{
	private int iValue;

	public int getiValue() {
		return iValue;
	}

	public void setiValue(int iValue) {
		this.iValue = iValue;
	}

	public checkPrimeNumber() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "checkPrimeNumber [iValue=" + iValue + "]";
	}
	
	
	
}
